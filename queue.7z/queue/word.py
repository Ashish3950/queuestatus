
import Excle 
import os
from docx  import Document
os.chdir('D:\\test')
doc=Document('test.docx')

def table1(tbl):
    for i,row in enumerate(tbl.rows,1):
        for j,rows in enumerate(row.cells,1) :
            if(i==1 or j==1):
                continue
            else:
                

def table2(tbl):
    return 'Currently working on'

for s,i in enumerate(doc.paragraphs,1):
    print(s)
    print(i.text)
    
for s,i in enumerate(doc.paragraphs,1):
    if(s==5):
        temp=Excle.totalincident()
        i.text=temp
    elif(s==6):
        temp=Excle.AUFincident()
        i.text=temp
    elif(s==7):
        temp=Excle.Assignedincident()
        i.text=temp
    elif(s==8):
        temp=Excle.wipincident()
        i.text=temp
    elif(s==9):
        temp=Excle.A3partyincident()
        i.text=temp
    elif(s==10):
        temp=Excle.Achangeincident()
        i.text=temp
    elif(s==13):
        temp=Excle.allreq()
        i.text=temp
for s,tb in enumerate(doc.tables,1):
    if(s==1):
        table1(tb)
    elif(s==2):
        table2(tb)
        
    
doc.save('new.docx')